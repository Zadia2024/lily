ReadData()
let btnAction="Insert";
$("#showModal").on("click", function(){
    $("#patientModal").modal("show");
   })

$("#pattientform").parsley();

$("#pattientform").on("submit",function(event){
    event.preventDefault();
    var name = $("#name").val();
    var phone = $("#phone").val();
    let address = $("#address").val();
    let  sex=$("#sex").val();
    let update_id = $("#update_id").val();
    let data={}
    if(btnAction == "Insert"){
         data={
            "name": name,
            "phone": phone,
            "address": address,
            "sex": sex,
            "action":"patientRegister"
        }
    }else{
         data={
            "name": name,
            "phone": phone, 
            "address": address,
            "sex": sex,
            "update_id": update_id,
            "action":"updatedata"
        }
    }
    
    console.log(data);
    $.ajax({
        method: "POST",
        dataType: "JSON",
        url:"../api/patient.php",
        data: data,
        success: function(data){
         let status=data.status;
         let response=data.data
         if(status){
            Swal.fire({
                position: "top-end",
                icon: "success",
                title: response,
                showConfirmButton: false,
                timer: 1500
              });
              ReadData()
              setTimeout(function(){
                $("#pattientform")[0].reset();
                $("#patientModal").modal("hide");
                $("#pattientform").parsley().reset();
              },2000)
              btnAction="Insert";
              
        }else{
            Swal.fire({
                position: "top-end",
                icon: "error", 
                title: "Oops...",
                text: response,
               
              });
         }
        
    },error:function(data){
        console.log(data)

    }
})
})


/////////ReadDtaa waye///////
function ReadData() {
    $("#dataTable tbody").html("");
    let data ={
        "action": "ReadData"
    }
    $.ajax({
        method:"POST",
        dataType:"json",
        url:"../api/patient.php",
        data:data,
        success:function(data){
        let status = data.status;
        let response= data.data;
         let tr="";
         if(status){
            tr="<tr>"
            response.forEach (function(result){
            tr+=`<td>${result.id}</td>`
            tr+=`<td>${result.name}</td>`
            tr+=`<td>${result.phone}</td>`
            tr+=`<td>${result.address}</td>`
            tr+=`<td>${result.sex}</td>`
            tr+=`<td>${result.date}</td>`
            tr+=
            `<td>
            <a class="btn btn-success update_info" update_id=${result.id}><i class="fas fa-pen"></i></a>
            <a class="btn btn-danger delete_info" delete_id=${result.id}><i class="fas fa-trash"></i></a>
            </td>`

            tr+="</tr>"
        })
        $("#dataTable tbody").append(tr)
        $('#dataTable').DataTable();
          }else{
          console.log(data)
          }
        },
        error:function(data){
          console.log(data)
        }
 })

 
}

////Update /////
$("#dataTable tbody").on("click","a.update_info",function(){
    let id=$(this).attr("update_id");
    let data={
        "action": "Feachdata",
        "id": id
    }
    $.ajax({
        method: "POST",
        dataType : "JSON",
        url:"../api/patient.php",
        data: data,
        "success": function(result){
            let status = result.status;
            let data=result.data;
            if(status){
                btnAction="update";
                $("#name").val(data.name);
                $("#phone").val(data.phone);
                $("#address").val(data.address);
                $("#sex").val(data.sex); 
                $("#update_id").val(data.id);           
                $("#patientModal").modal("show");
                ReadData()
            }else{
                console.log(data)
            }
        },error: function(result) {

        }
    })
})

///////Dlete //////
$("#dataTable tbody").on("click","a.delete_info",function(){
    let id=$(this).attr("delete_id");
    Swal.fire({
        title: "Are you sure?",
        text: "You Want To Delete This Patient!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then((result) => {
        if (result.isConfirmed) {
            deletedata(id)
        }
      });
})

function deletedata(id){
    let data={
        "action": "deletedata",
        "id": id
    }
    $.ajax({
        method: "POST",
        dataType : "JSON",
        url:"../api/patient.php",
        data: data,
        "success": function(result){
            let status = result.status;
            let data=result.data;
            if(status){
                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: data,
                    showConfirmButton: false,
                    timer: 1500
                });
                ReadData()
            }else{
                console.log(data)
            }
        },error: function(result) {

        }
    })
}