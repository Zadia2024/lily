Readpatient()
ReadInvoiceNumber()
//Submision studentReport
$("#searchReport").on("submit",function(e){
  e.preventDefault();
  $("#dataTable tbody").html("")
  let data=new FormData($("#searchReport")[0])
    data.append("action","paymentReport")
  $.ajax({
    method:"POST",
    dataType:"JSON",
    url:"../api/patient_Report.php",
    data:data,
    processData:false,
    contentType:false,
    success:function(data){
        let status=data.status;
        let response=data.data;
        if(status){
          tr="<tr>"
          response.forEach(function(res){
          for(let i in res){
          
            if(i=="Pateints"){
            
               if(res[i]=="unpaid"){
                      tr+=`<td><span class="badge bg-danger text-light">${res[i]}</span></td>`

                  }else{
                      tr+=`<td><span class="badge bg-success text-light">${res[i]}</span></td>`

                  }
            }else{
              tr+=`<td>${res[i]}</td>`
            }
          }
            tr+="</tr>"
          })

        $("#dataTable tbody").html(tr)
          
        // $("#dataTable").DataTable();
         

          }else{
            console.log(response)
        }

    },error:function(data){

    }
})
})
function Readpatient(){
  $("#dataTable tbody").html("")
  let data={
    "action":"ReadData"
  }
  $.ajax({
    method: "POST",
    dataType: "JSON",
    url: "../api/patient.php",
    data: data,
    success: function(data){
    let status = data.status;
    let response= data.data;
    let option="";
    if(status){
      option =`<option value=''>Please Select Patient Name</option>`
    response.forEach(function(res){
    option+=`<option value='${res.name}'>${res.name}</option>`

    })
    $("#PateintName").html(option)
          }else{
          console.log(data)
          }
        },error:function(data){
          console.log(data)
        }
      })
}
function ReadInvoiceNumber(){
    $("#dataTable tbody").html("")
    let data={
      "action":"ReadData"
    }
    $.ajax({
      method: "POST",
      dataType: "JSON",
      url: "../api/patient.php",
      data: data,
      success: function(data){
      let status = data.status;
      let response= data.data;
      let option="";
      if(status){
        option =`<option value=''>Please Select Invoice Number</option>`

      response.forEach(function(res){
      option+=`<option value='${res.phone}'>${res.phone}</option>`
  
      })
      $("#ptphone").html(option)
            }else{
            console.log(data)
            }
          },error:function(data){
            console.log(data)
          }
        })
}
$("#print").on("click",function(){
  Printpayment()
})

const Printpayment=()=>{
  let w=window.open();
  w.document.write('<link rel="stylesheet" href="../../assets/css/style.css">')
  w.document.write($("#printsection").html());
  w.print()
  w.close()
}