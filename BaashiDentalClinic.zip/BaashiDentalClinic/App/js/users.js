ReadData()
let btnAction="Insert";
$("#showModal").on("click", function(){
    $("#UsersModal").modal("show");
   })

$("#Usersform").parsley();

$("#Usersform").on("submit",function(event){
    event.preventDefault();
    let data=new FormData($("#Usersform")[0])
    if(btnAction == "Insert"){
    data.append("action","UsersRegister")
    }else{
    data.append("action","updateData")
    }
    
    console.log(data);
    $.ajax({
        method: "POST",
        dataType: "JSON",
        url:"../api/users.php",
        data: data,
        processData: false,
        contentType: false,
        success: function(data){
         let status=data.status;
         let response=data.data
         if(status){
            Swal.fire({
                position: "top-end",
                icon: "success",
                title: response,
                showConfirmButton: false,
                timer: 1500
              });
              ReadData()
              setTimeout(function(){
                $("#Usersform")[0].reset();
                $("#UsersModal").modal("hide");
                $("#Usersform").parsley().reset();
              },2000)
              btnAction="Insert";
              
        }else{
            Swal.fire({
                position: "top-end",
                icon: "error", 
                title: "Oops...",
                text: response,
               
              });
         }
        
    },error:function(data){
        console.log(data)

    }
})
})


/////////ReadDtaa waye///////
function ReadData() {
    $("#dataTable tbody").html("");
    let data ={
        "action": "ReadData"
    }
    $.ajax({
        method:"POST",
        dataType:"json",
        url:"../api/users.php",
        data:data,
        success:function(data){
        let status = data.status;
        let response= data.data;
         let tr="";
         if(status){
            tr="<tr>"
            response.forEach (function(result){
            tr+=`<td>${result.id}</td>`
            tr+=`<td>${result.username}</td>`
            tr+=`<td>${result.password}</td>`
            tr+=`<td>${result.type}</td>`
            tr+=`<td>${result.status}</td>`
            tr+=`<td>${result.date}</td>`
            tr+=
            `<td>
            <a class="btn btn-success update_info" update_id=${result.id}><i class="fas fa-pen"></i></a>
            <a class="btn btn-danger delete_info" delete_id=${result.id}><i class="fas fa-trash"></i></a>
            </td>`

            tr+="</tr>"
        })
        $("#dataTable tbody").append(tr)
        $('#dataTable').DataTable();
          }else{
          console.log(data)
          }
        },
        error:function(data){
          console.log(data)
        }
 })

 
}

////Update /////
$("#dataTable tbody").on("click","a.update_info",function(){
    let id=$(this).attr("update_id");
    let data={
        "action": "Feachdata",
        "id": id
    }
    $.ajax({
        method: "POST",
        dataType : "JSON",
        url:"../api/users.php",
        data: data,
        "success": function(result){
            let status = result.status;
            let data=result.data;
            if(status){
                btnAction="update";
                $("#username").val(data.username);
                $("#password").val(data.password);
                $("#type").val(data.type);
                $("#Ai").val(data.status); 
                $("#update_id").val(data.id);           
                $("#UsersModal").modal("show");
                ReadData()
            }else{
                console.log(data)
            }
        },error: function(result) {

        }
    })
})

///////Dlete //////
$("#dataTable tbody").on("click","a.delete_info",function(){
    let id=$(this).attr("delete_id");
    Swal.fire({
        title: "Are you sure?",
        text: "You Want To Delete This Users!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then((result) => {
        if (result.isConfirmed) {
            deletedata(id)
        }
      });
})

function deletedata(id){
    let data={
        "action": "deletedata",
        "id": id
    }
    $.ajax({
        method: "POST",
        dataType : "JSON",
        url:"../api/users.php",
        data: data,
        "success": function(result){
            let status = result.status;
            let data=result.data;
            if(status){
                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: data,
                    showConfirmButton: false,
                    timer: 1500
                });
                ReadData()
            }else{
                console.log(data)
            }
        },error: function(result) {

        }
    })
}