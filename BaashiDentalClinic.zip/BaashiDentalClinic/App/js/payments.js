let btnAction = "Insert"

ReadPateint()
ReadAccount() 
ReadData()

$("#showModal").on("click", function(){
    $("#paymentsModal").modal("show");
})
$("#paymentsform").parsley();

$("#paymentsform").on("submit",function(event){
    event.preventDefault();
    let formData=new FormData($("#paymentsform")[0])
    if(btnAction == "Insert"){
        formData.append("action","payment")
    }else{

    }

    $.ajax({
        method: "POST",
        dataType: "JSON",
        url:"../api/payments.php",
        data: formData,
        processData:false,
        contentType: false,
        success: function(data){
         let status=data.status;
         let response=data.data
         if(status){

            Swal.fire({
                position: "top-end",
                icon: "success",
                title: response,
                showConfirmButton: false,
                timer: 1500
              });
                ReadData()
                $("#paymentsform")[0].reset();
                $("#paymentsModal").modal("hide");
                $("#paymentsform").parsley().reset();
              btnAction="Insert";
              
        }else{
            Swal.fire({
                position: "top-end", 
                icon: "error", 
                title: "Oops...",
                text: response,
              });
         }
        
    },error:function(data){
        console.log(data)

    }
})
})




function ReadPateint() {
    let data={
        "action":"pateintwithblance"
    }
    $.ajax({
        method: "POST",
        dataType: "JSON",
        url: "../api/patient.php",
        data: data,
       success:function(data){
        let status=data.status;
        let response=data.data;
        let optaions="";
        if(status){
            optaions="<option value=''>Please Select Patient</option>";
            response.forEach(res=>{
                optaions+=`<option value=${res.pt_id}>${res.name}</option>`
            })
            console.log(response)
            $("#pt_id").html(optaions)
        }else{

        }



       },error:function(data){
        console.log(data)
       }

    })
}

function ReadAccount() {
    let data={
        "action":"ReadData"
    }
    $.ajax({
        method: "POST",
        dataType: "JSON",
        url: "../api/account.php",
        data: data,
       success:function(data){
        let status=data.status;
        let response=data.data;
        let optaions="";
        if(status){
            optaions="<option value=''>Please Select Account</option>";
            response.forEach(res=>{
                optaions+=`<option value=${res.id}>${res.number }</option>`
    
            
            })
            $("#account_id").html(optaions)
        }else{

        }



       },error:function(data){
        console.log(data)
       }

    })
}

$("#pt_id").change(function(){
    let id=$(this).val();
    pateintInfo(id)
})

function pateintInfo(id){
    let data={
        "action":"pateintInfo",
        "pt_id":id
    }
    $.ajax({
        method: "POST",
        dataType: "JSON",
        url: "../api/payments.php",
        data: data,
       success:function(data){
        let status=data.status;
        let response=data.data;
        if(status){
            $("#amount").val(response.balance)
            $("#blance").val(response.balance)
            console.log(response)

        }else{

        }



       },error:function(data){
        console.log(data)
       }

    })
}

// $("#amount_paid").on("keypress",function(event){
//     calculate(event.target.id)

// })

// $("#discount").on("keypress",function(event){
//     calculate(event.target.id)

// })
$("#amount_paid").keypress(function(event){
    calculate(event.target.id)
  
    })
$("#discount").keypress(function(event){
    calculate(event.target.id)
  
    })

function calculate(event){
    let amount=$("#amount").val();
    let paid=$("#amount_paid").val();
    let discount=$("#discount").val();
    let total=amount-discount-paid;
    let blance=$("#blance").val();
    if(event=="amount_paid"){
        if(paid>blance){
            $("#amount_paid").val("");
        }else{
            $("#blance").val(total);
        }

    }else{
        if(discount>blance){
            $("#discount").val("");
        }else{
            $("#blance").val(total);
        }
    }

}

function ReadData() {
    $("#dataTable tbody").html("");
    let data ={
        "action": "ReadData"
    }
    $.ajax({
        method:"POST",
        dataType:"json",
        url:"../api/payments.php",
        data:data,
        success:function(data){
        let status = data.status;
        let response= data.data;
         let tr="";
         if(status){
            tr="<tr>"
            th="<th>"
            
            response.forEach (function(result){
                for (let i in result){
                    th+=`<th>${i}</th>`
                }
                th+=`<th>Actions</th>`
                th+="</tr>"
                for(let i in result){
                    // if(i=="status"){
                    //     if(result[i]=="unpaid"){
                        // tr+=<td><span class="badge bg-danger text-light">${res[i]}</span></td>
                    //     }else{
                        // tr+=<td><span class="badge bg-success text-light">${res[i]}</span></td>
                    //     }
                    // }else{
                        
                    // }
                     tr+=`<td>${result[i]}</td>`
                }
                
            
            tr+=`
           <td>
            <a class="btn btn-success update_info" update_id=${result.id}><i class="fas fa-pen"></i></a>
            <a class="btn btn-danger delete_info" delete_id=${result.id}><i class="fas fa-trash"></i></a>
            </td>`

            tr+="</tr>"
        })
        $("#dataTable tbody").append(tr)
        $("#dataTable thead").append(th)
        $('#dataTable').DataTable();
          }else{
          console.log(data)
          }
        },
        error:function(data){
          console.log(data)
        }
 })

 
}