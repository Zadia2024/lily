let btnAction="Insert";
ReadData()


$("#showModal").on("click", function(){
    $("#doctorModal").modal("show");
})

$("#doctorform").parsley();



$("#doctorform").on("submit", function(event){
    event.preventDefault();
    let name = $("#name").val();
    let phone = $("#phone").val();
    let national = $("#national").val();
    let Qualification = $("#Qualification").val();
    let salary = $("#salary").val();
    let update_id = $("#update_id").val();
    let data={}
    if(btnAction == "Insert"){
     data={
        "name":name,
        "phone":phone,
        "national":national,
        "Qualification":Qualification,
        "salary":salary,
        "action":"createdoctor"
        }
    }else {
        data={
         "name":name,
         "phone":phone,
         "national":national,
         "Qualification":Qualification,
         "salary":salary,
         "action":"updateData",
         "id":update_id
        }
    }

    $.ajax({
        method:"POST",
        dataType:"JSON",
        url:"../api/doctor.php",
        data:data,
        success:function(data){
            let status = data.status;
            let response = data.data;
            if(status){
                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: response,
                    showConfirmButton: false,
                    timer: 1500
                  });
                    $("#doctorform")[0].reset();
                    $("#doctorModal").modal("hide");
                    $("#doctorform").parsley().reset();
                    ReadData()
                    btnAction="Insert";
                  
            }else{
                Swal.fire({
                    position: "top-end",
                    icon: "error", 
                    title: "Oops...",
                    text: response,
                    
                  });
            }
        
        
        },error:function(data){

            console.log(data)

        }

        })










})    



function ReadData(){
    let data={
        "action": "ReadData"
    }

    $.ajax({
        method: "POST",
        dataType: "JSON",
        url:"../api/doctor.php",
        data:data,
        success: function(data){
            let status = data.status;
            let response = data.data;
            let tr="";
            if(status){
                tr="<tr>"
                response.forEach(function(res){
              
                for (let i in res){    
                
                 tr+=`<td>${res[i]}</td>`
                }
                tr+=`
                <td>
                <a  class="btn btn-success update_info" update_id=${res.id}><i class="fa fa-pen"></i></a>
                <a  class="btn btn-danger delete_info" delete_id=${res.id}><i class="fa fa-trash"></i></a>
                </td>`

                 tr+="</tr>"

                })

               $("#dataTable tbody").html(tr)


            }else{
                console.log(response)
            }
        },error: function(data){

        }
    })
}



$("#dataTable tbody").on("click", "a.update_info", function(){
    var id= $(this).attr("update_id");

    let data={
        "action": "FeachData",
        "id": id,
    }

    $.ajax({
        method: "POST",
        dataType: "JSON",
        url:"../api/doctor.php",
        data:data,
        success: function(data){
            let status = data.status;
            let response = data.data;
            if(status){
                btnAction="update";
                $("#name").val(response.name);
                $("#phone").val(response.phone);
                $("#national").val(response.national);
                $("#Qualification").val(response.Qualification); 
                $("#salary").val(response.salary); 
                $("#update_id").val(response.id);           
                $("#doctorModal").modal("show");

            }else{
                console.log(response)
            }
        },error: function(data){

        }
    })
})




$("#dataTable tbody").on("click", "a.delete_info", function(){
    var id= $(this).attr("delete_id");
    Swal.fire({
        title: "Are you sure?",
        text: "You Want To Delete This Doctor 👨‍⚕️!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then((result) => {
        if (result.isConfirmed) {
            let data={
                "action": "deleteData",
                "id": id,
            }
        
            $.ajax({
                method: "POST",
                dataType: "JSON",
                url:"../api/doctor.php",
                data:data,
                success: function(data){
                    let status = data.status;
                    let response = data.data;
                    if(status){
                        Swal.fire({
                            position: "top-end",
                            icon: "success",
                            title: response,
                            showConfirmButton: false,
                            timer: 1500
                          });
                          ReadData()
                    }else{
                        console.log(response)
                    }
                },error: function(data){
        
                }
            })
        }
      });



})