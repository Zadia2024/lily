

$("#login").on("submit", function(event){
    event.preventDefault();
    let data=new FormData($("#login")[0])

    data.append("action","login")
    $.ajax({
        method:"POST",
        dataType:"JSON",
        url:"App/api/login.php",
        data:data,
        processData:false,
        contentType:false,
        success:function(data){
            let status = data.status;
            let response = data.data;
            if(status){
                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: response,
                    showConfirmButton: false,
                    timer: 1500
                  });
                    setTimeout(function(){
                    window.location="App/views/index.php";
                  },3000)
            }else{
                Swal.fire({
                    position: "top-end",
                    icon: "error", 
                    title: "Oops...",
                    text: response,
                    
                  });
            }
        
        
        },error:function(data){

            console.log(data)

        }

        })










})   