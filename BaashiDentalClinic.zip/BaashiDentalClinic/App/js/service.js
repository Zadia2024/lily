let btnAction="Insert";
ReadData()


$("#showModal").on("click", function(){
    $("#serviceModal").modal("show");
})

$("#serviceform").parsley();



$("#serviceform").on("submit", function(event){
    event.preventDefault();
    let data=new FormData($("#serviceform")[0])


    let update_id = $("#update_id").val();
    
    if(btnAction == "Insert"){
     data.append("action","CreateService")
    }else {
        data.append("action","updateData")
    }

    $.ajax({
        method:"POST",
        dataType:"JSON",
        url:"../api/service.php",
        data:data,
        processData:false,
        contentType:false,
        success:function(data){
            let status = data.status;
            let response = data.data;
            if(status){
                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    title: response,
                    showConfirmButton: false,
                    timer: 1500
                  });
                    $("#serviceform")[0].reset();
                    $("#serviceModal").modal("hide");
                    $("#serviceform").parsley().reset();
                    ReadData()
                    btnAction="Insert";
                  
            }else{
                Swal.fire({
                    position: "top-end",
                    icon: "error", 
                    title: "Oops...",
                    text: response,
                    
                  });
            }
        
        
        },error:function(data){

            console.log(data)

        }

        })










})    



function ReadData(){
    let data={
        "action": "ReadData"
    }

    $.ajax({
        method: "POST",
        dataType: "JSON",
        url:"../api/service.php",
        data:data,
        success: function(data){
            let status = data.status;
            let response = data.data;
            let tr="";
            if(status){
                tr="<tr>"
                response.forEach(function(res){
              
                for (let i in res){    
                
                 tr+=`<td>${res[i]}</td>`
                }
                tr+=`
                <td>
                <a  class="btn btn-success update_info" update_id=${res.id}><i class="fa fa-pen"></i></a>
                <a  class="btn btn-danger delete_info" delete_id=${res.id}><i class="fa fa-trash"></i></a>
                </td>`

                 tr+="</tr>"

                })

               $("#dataTable tbody").html(tr)


            }else{
                console.log(response)
            }
        },error: function(data){

        }
    })
}



$("#dataTable tbody").on("click", "a.update_info", function(){
    var id= $(this).attr("update_id");

    let data={
        "action": "FeachData",
        "id": id,
    }

    $.ajax({
        method: "POST",
        dataType: "JSON",
        url:"../api/service.php",
        data:data,
        success: function(data){
            let status = data.status;
            let response = data.data;
            if(status){
                btnAction="update";
                $("#name").val(response.name);
                $("#price").val(response.price);
                $("#update_id").val(response.id);           
                $("#serviceModal").modal("show");

            }else{
                console.log(response)
            }
        },error: function(data){

        }
    })
})




$("#dataTable tbody").on("click", "a.delete_info", function(){
    var id= $(this).attr("delete_id");
    Swal.fire({
        title: "Are you sure?",
        text: "You Want To Delete This Service 👨‍⚕️!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then((result) => {
        if (result.isConfirmed) {
            let data={
                "action": "deleteData", 
                "id": id,
            }
        
            $.ajax({
                method: "POST",
                dataType: "JSON",
                url:"../api/service.php",
                data:data,
                success: function(data){
                    let status = data.status;
                    let response = data.data;
                    if(status){
                        Swal.fire({
                            position: "top-end",
                            icon: "success",
                            title: response,
                            showConfirmButton: false,
                            timer: 1500
                          });
                          ReadData()
                    }else{
                        console.log(response)
                    }
                },error: function(data){
        
                }
            })
        }
      });



})