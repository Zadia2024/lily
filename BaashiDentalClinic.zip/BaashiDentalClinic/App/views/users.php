
<!-- [ Head ] start -->
<?php
        include("./head.php");
        session_start();
        if(empty($_SESSION['id'])){
        header("location:../../index.php");
        }else if($_SESSION['type']!="Admin"){
        header("location:../../index.php?error=you are not admin");  
        }
    ?>
<body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<!-- [ Pre-loader ] End -->
	<!-- [ navigation menu ] start -->
    <?php
        include("./sidebar.php");
    ?>
	<!-- [ navigation menu ] end -->



	<!-- [ Header ] start -->
    <?php
        include("./header.php");
    ?>
	<!-- [ Header ] end -->
	
	

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard Analytics</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard Analytics</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
</div>

<div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Striped Table</h5>
                        <button class="btn btn-success float-right" id="showModal"><i class="fas fa-plus"></i></button>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Username</th>
                                        <th>Password</th>
                                        <th>User Type</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                            
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>



<div class="modal" tabindex="-1" id="UsersModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Users Form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
      </div>
      <div class="modal-body">
      <form id="Usersform">
        <input type="hidden" id="update_id" name="id">
        <label>Username</label>
        <input type="text" name="username" id="username" placeholder="Enter UserName " class="form-control" required>
        <label>Password</label>
        <input type="password" name="password" id="password" placeholder="Enter Password " class="form-control" required>
        <label for="">User Type</label>
        <select name="type" id="type" class="form-control">
            <option value="Admin">Admin</option>
            <option value="user">User</option>
        </select>
        <label for="">Status</label>
        <select name="status" id="status" class="form-control">
            <option value="Enable">Enable</option>
            <option value="Disable">Disable</option>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
        </form>
      </div>
    </div>
  </div>
</div>





    <!-- Required Js -->
    <?php
        include("./script.php");
    ?>



     <script src="../js/users.js"></script>