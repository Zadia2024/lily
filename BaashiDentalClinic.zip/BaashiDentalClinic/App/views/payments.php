
<!-- [ Head ] start -->
<?php
        include("./head.php");
        session_start();
        if(empty($_SESSION['id'])){
        header("location:../../index.php");
        }else if($_SESSION['type']!="Admin"){
        header("location:../../index.php?error=you are not admin");  
        }
    ?>
<body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<!-- [ Pre-loader ] End -->
	<!-- [ navigation menu ] start -->
    <?php
        include("./sidebar.php");
    ?>
	<!-- [ navigation menu ] end -->



	<!-- [ Header ] start -->
    <?php
        include("./header.php");
    ?>
	<!-- [ Header ] end -->
	
	

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard Analytics</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard Analytics</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
</div>

<div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Striped Table</h5>
                        <button class="btn btn-success float-right" id="showModal"><i class="fas fa-plus"></i></button>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-bordered table-striped">
                                <thead>
                                </thead>
                                <tbody>
                            
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>



<div class="modal" tabindex="-1" id="paymentsModal">
  <div class="modal-dialog modal-xl" >
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
      </div>
      <div class="modal-body">
      <form id="paymentsform">
<div class="row">
    <div class="col-4">
         <label for="">Patient</label>
        <select name="pt_id" id="pt_id" class="form-control" required>
        </select>
    </div>
    <div class="col-4">
         <label for="">Amount</label>
        <input type="text" name="amount" id="amount" class="form-control" required readonly>
    </div>
    <div class="col-4">
         <label for="">paid_amount</label>
        <input type="text" name="amount_paid" id="amount_paid" class="form-control" required>
    </div>
</div>
 <div class="row">
        <div class="col-4">
         <label for="">Discount</label>
        <input name="discount" id="discount" class="form-control" required value="0">
    </div>
    <div class="col-4">
         <label for="">Balance</label>
        <input name="blance" id="blance" class="form-control" required value="0" readonly>
    </div>
    <div class="col-4">
         <label for="">Account</label>
        <select name="account_id" id="account_id" class="form-control" required>
        </select>
    </div>
 </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
        </form>
      </div>
    </div>
  </div>
</div>





    <!-- Required Js -->
    <?php
        include("./script.php");
    ?>



     <script src="../js/payments.js"></script>