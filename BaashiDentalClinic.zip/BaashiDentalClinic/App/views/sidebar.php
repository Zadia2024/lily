	<!-- [ navigation menu ] start -->
	<nav class="pcoded-navbar  ">
		<div class="navbar-wrapper  ">
			<div class="navbar-content scroll-div " >
				
				<div class="">
					<div class="main-menu-header">
						<img class="img-radius" src="../../assets/images/user/avatar-2.jpg" alt="User-Profile-Image">
						<div class="user-details">
							<span><?php echo $_SESSION['username']?></span>
						</div>
					</div>
					
				</div>
				
				<ul class="nav pcoded-inner-navbar ">
				<li class="nav-item">
					    <a href="index.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
					</li>
					<li class="nav-item">
					    <a href="patient.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-file-text"></i></span><span class="pcoded-mtext">Patient</span></a>
					</li>
				<?php
                //    session_start();
                   if($_SESSION['type']=="Admin"){ 
                    ?>
					<li class="nav-item">
					    <a href="patientReport.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">PatientReport</span></a>
					</li>
						<li class="nav-item">
					    <a href="service.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">Service</span></a>
					</li>
					<li class="nav-item">
					    <a href="doctors.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">Doctor</span></a>
					</li>
					<li class="nav-item">
					    <a href="equipment.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">Equipment</span></a>
					</li>
					<li class="nav-item">
					    <a href="recieption.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">Recieption</span></a>
					</li>
					<li class="nav-item">
					    <a href="payments.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">payment</span></a>
					</li>
					<li class="nav-item">
					    <a href="payment_report.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">paymentReport</span></a>
					</li>
					
					
					<li class="nav-item">
					    <a href="account.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">Account</span></a>
					</li>
					<li class="nav-item">
					    <a href="users.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">Users</span></a>
					</li>
               <?php
                 
                }else{

                }
                  ?>
					
				</ul>
			</div>
		</div>
	</nav>
	<!-- [ navigation menu ] end -->