
<!-- [ Head ] start -->
<?php
        include("./head.php");
        session_start();
        if(empty($_SESSION['id'])){
        header("location:../../index.php");
        }else if($_SESSION['type']!="Admin"){
        header("location:../../index.php?error=you are not admin");  
        }
    ?>
<body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<!-- [ Pre-loader ] End -->
	<!-- [ navigation menu ] start -->
    <?php
        include("./sidebar.php");
    ?>
	<!-- [ navigation menu ] end -->



	<!-- [ Header ] start -->
    <?php
        include("./header.php");
    ?>
	<!-- [ Header ] end -->
	
	

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard Analytics</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard Analytics</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
</div>

<div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Striped Table</h5>
                        <button class="btn btn-success float-right" id="showModal"><i class="fas fa-plus"></i></button>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>National</th>
                                        <th>Qualification</th>
                                        <th>Salary</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                            
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>



<div class="modal" tabindex="-1" id="doctorModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
      </div>
      <div class="modal-body">
      <form id="doctorform">
        <input type="hidden" id="update_id">
        <label>Name</label>
        <input type="text" name="name" id="name" placeholder="Enter Doctor Name " class="form-control" required>
        <label>phone</label>
        <input type="number" name="phone" id="phone" placeholder="Enter Doctor phone " class="form-control" required>
        <label>National</label>
        <input type="text" name="national" id="national" placeholder="Enter Doctor National " class="form-control" required>
        <label>Qualification</label>
        <input type="text" name="Qualification" id="Qualification" placeholder="Enter Qualification " class="form-control" required>
        <label>Salary</label>
        <input type="number" name="salary" id="salary" placeholder="Enter Doctor Salary " class="form-control" required>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
        </form>
      </div>
    </div>
  </div>
</div>





    <!-- Required Js -->
    <?php
        include("./script.php");
    ?>



     <script src="../js/doctor.js"></script>