
<!-- [ Head ] start -->
    <?php
        include("./head.php");
        session_start();
    ?>
<body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<!-- [ Pre-loader ] End -->
	<!-- [ navigation menu ] start -->
    <?php
        include("./sidebar.php");
    ?>
	<!-- [ navigation menu ] end -->



	<!-- [ Header ] start -->
    <?php
        include("./header.php");
    ?>
	<!-- [ Header ] end -->
	
	

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard Analytics</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard Analytics</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
</div>

<div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Striped Table</h5>
                        <button class="btn btn-success float-right" id="showModal"><i class="fas fa-plus"></i></button>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Sex</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                            
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
</div>



<div class="modal" tabindex="-1" id="patientModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
      </div>
      <div class="modal-body">
      <form id="pattientform">
        <input type="hidden" id="update_id">
        <label>Name</label>
        <input type="text" name="name" id="name" placeholder="Enter Pattient Name " class="form-control" required>
        <label>phone</label>
        <input type="number" name="phone" id="phone" placeholder="Enter Pattient phone " class="form-control" required>
        <label>Address</label>
        <input type="text" name="address" id="address" placeholder="Enter Pattient address " class="form-control" required>
        <label>select</label>
        <select name="sex" name="sex" id="sex"  class="form-control" required>
        <option value="">Please select sex</option>
        <option value="male">male</option>
        <option value="female">female</option>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
        </form>
      </div>
    </div>
  </div>
</div>





    <!-- Required Js -->
    <?php
        include("./script.php");
    ?>



     <script src="../js/patient.js"></script>