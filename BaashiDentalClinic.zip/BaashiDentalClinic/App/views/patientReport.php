<!-- [ Head ] start -->
<?php
        include("./head.php");
        session_start();
        if(empty($_SESSION['id'])){
        header("location:../../index.php");
        }else if($_SESSION['type']!="Admin"){
        header("location:../../index.php?error=you are not admin");  
        }
    ?>
<body class="">
	<!-- [ Pre-loader ] start -->
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<!-- [ Pre-loader ] End -->
	<!-- [ navigation menu ] start -->
    <?php
        include("./sidebar.php");
    ?>
	<!-- [ navigation menu ] end -->



	<!-- [ Header ] start -->
    <?php
        include("./header.php");
    ?>
	<!-- [ Header ] end -->
	
	

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard Analytics</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard Analytics</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->


      <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                    <form id="searchReport">
                                        <div class="row">
                                          
                                            <div class="col">
                                                <label for="">Patient Name</label>
                                                <select name="PateintName" id="PateintName" class="form-control" >  

                                                </select>
                                                </div>
                                             
                                            <div class="col">
                                                <label for="">SEX</label>
                                                <select name="Pateints" id="Pateints" class="form-control" >  
                                                <option value="">Please Select Status</option>
                                               <option value="male">male</option>
                                               <option value="female">female</option>

                                                </select>
                                            </div>
                                            <div class="col">
                                                <label for="">Phone</label>
                                                <select name="ptphone" id="ptphone" class="form-control" >  

                                                </select>
                                            </div>
                                            <div class="col">
                                                <label for="">From Date</label>
                                                <input type="date" class="form-control" id="from" name="from">
                                            </div>
                                            <div class="col">
                                                <label for="">To Date</label>
                                                <input type="date" class="form-control" id="to" name="to">
                                            </div>
                                            <div class="col-2 mt-3">
                                              <button type="submit" class="btn btn-success mt-3">Search</button>
                                            </div>
                                           
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Striped Table</h5>
                       
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                        <div id="printsection">
                        <div class="row">
                           <div class="col-12">
                             <img src="../../images/lkjh.jpg" alt="sawirlogo" style="width:100%;height:200px">
                              </div>
                              </div>
                            <table id="dataTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                           <th>Patient Name</th>
                                            <th>Phone</th>
                                            <th>Address</th>
                                            <th>Sex</th>
                                            <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                            
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <button class="btn btn-success" id="print"><i class="fas fa-print"></i></button>
                </div>
</div>
<!-- end col-->
                    </div>
    </div>
</div>
 





    <!-- Required Js -->
    <?php
        include("./script.php");
    ?>



     <script src="../js/pateint_report.js"></script>