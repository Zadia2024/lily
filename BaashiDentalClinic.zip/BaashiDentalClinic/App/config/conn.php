<?php
$conn=new mysqli("localhost","root","","BaashiDentalClinic");
if($conn){
    // echo "Connected";
}else{
    echo $conn->error;
}

?>