<?php
include "../config/conn.php";

function payment($conn){
    extract($_POST);
    $data=[];
    $query="CALL payment_ps('$pt_id','$amount','$amount_paid','$discount','$blance','$account_id','user132')";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result); 
        if($row['msg']=='paid_amount'){
        $data=array("status"=>false,"data"=>"Paid Amount must be less than or Equal Price");
        }else if($row['msg']=='discount'){
        $data=array("status"=>false,"data"=>"Discount must be less than Price");
        }else{
            $data=array("status"=>true,"data"=>"pateint Paid successfully");
        }
        
    }else{  
    $data=["status"=>false,"data"=>$conn->error];
   }
   echo json_encode($data);
}
 
function pateintInfo($conn){
    extract($_POST);
    $data=[];
    $query="CALL pateintInfo('$pt_id') ";
    $result=mysqli_query($conn,$query);
    if($result){
     ($row=mysqli_fetch_assoc($result));

     $data=array("status"=>true,"data"=>$row);
    }else{  
    $data=["status"=>false,"data"=>$conn->error];
   }
   echo json_encode($data);
}

///// data soo aqrin function keeda
   function ReadData($conn){
    $data=[];
    $container=array();
    $query="SELECT p.id,pt.name patientName,p.amount,p.amount_paid,p.discount,p.blance,p.invoice,u.username,ac.number,p.status,p.date FROM payment p LEFT JOIN patient pt ON p.pt_id=pt.id LEFT JOIN users u ON p.user_id=u.id LEFT JOIN account ac ON p.account_id=ac.id";
    $result=mysqli_query($conn,$query);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
        array_push($container,$row);    
        }
        $data=array("status"=>true,"data"=>$container);
    }else{  
    $data=["status"=>false,"data"=>$conn->error];
   }
   echo json_encode($data);
}

function pateintwithblance($conn){
    $data=[];
    $container=array();
    $query="SELECT r.patient,p.name FROM recieption r LEFT JOIN patient p ON r.patient=p.id WHERE r.price>0 GROUP BY p.id";
    $result=mysqli_query($conn,$query);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
        array_push($container,$row);    
        }
        $data=array("status"=>true,"data"=>$container);
    }else{  
    $data=["status"=>false,"data"=>$conn->error];
   }
   echo json_encode($data);
}
/////////////// Aqrinta intan ku ek ///////////////////

/////////////// Update  ///////////////////

function Feachdata($conn){
    extract($_POST);
    $data=array();
    $query="SELECT * FROM patient WHERE patient.id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result);
        $data=array("status"=>true,"data"=>$row);
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);

}

//////////udata/////////////

function updatedata($conn){
    $data=array();
    extract($_POST);
    $query="UPDATE patient SET name='$name',phone='$phone',address='$address',sex='$sex' WHERE id='$update_id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data updated successfully");
    }else{
        $data=array("status"=>true,"data"=>$conn->error);
}
    echo json_encode($data);
}

///////Delete waaye/////////

function deletedata($conn){
    $data=array();
    extract($_POST);
    $query="DELETE FROM patient WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data Deleted successfully");
    }else{
        $data=array("status"=>true,"data"=>$conn->error);
}
    echo json_encode($data);
}




if(isset($_POST['action'])){
    
    $action=$_POST['action'];
    $action($conn);
}else{
   echo json_encode($data=array("data"=>"action required")); 
}