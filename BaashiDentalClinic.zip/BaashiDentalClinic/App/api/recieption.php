<?php

session_start();
function Recieption($conn){
    extract($_POST);
    $data=array();
    $query="CALL recieption('$pt_id','$d_id','$s_id','$price','$_SESSION[id]')";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result);
        if($row['msg']=="exist"){
            $data=array("status"=>false,"data"=>"😜Patient Allready Registered🫣");
        }else{
            $data=array("status"=>true,"data"=>"🫥Patient Recieption Successfully👌");
        }
    }else{
    // echo $conn->error;
    $data=array("status"=>false,"data"=>$conn->error);
}
      echo json_encode($data);
}


function ReadData($conn){
    $data=array();
    $container=array();
    $query="SELECT r.id,p.name patteint,d.name doctors ,s.name service,r.price,r.balance,r.date FROM `recieption` r LEFT JOIN patient p ON r.pt_id=p.id LEFT JOIN doctors d ON r.d_id=d.id LEFT JOIN service s ON r.s_id=s.id";
    $result=mysqli_query($conn,$query);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
         $data=array("status"=>true,"data"=>$row);
         array_push($container,$row);
        }
        $data=array("status"=>true,"data"=>$container);
    }else{
    $data=array("status"=>false,"data"=>$conn->error);
    }

    echo json_encode($data);
}


function FeachData($conn){
    $data=array();
    extract($_POST);
    $query="SELECT * FROM recieption WHERE id ='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
         $row=mysqli_fetch_assoc($result);
         $data=array("status"=>true,"data"=>$row);

    }else{
    $data=array("status"=>false,"data"=>$conn->error);
    }

    echo json_encode($data);
}



function updateData($conn){
    extract($_POST);
    $data=array();
    $query="UPDATE recieption SET patient='$patient', d_id='$d_id', s_id='$s_id', price='$price' WHERE id='$update_id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>" ✍️ Data updated successfully ✔️");
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);
}


function deleteData($conn){
    extract($_POST);
    $data=array();
    $query="DELETE FROM recieption WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data Deleted successfully");
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);
}








include "../config/conn.php";

if(isset($_POST['action'])){
    $action=$_POST['action'];
    $action($conn);
}else{
    echo json_encode(array("status"=>false,"data"=>"action not found"));
}




?>