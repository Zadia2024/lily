<?php

include "../config/conn.php";


function paymentReport($conn){
    extract($_POST);
    $data=[];
    $container=[];
    $query="CALL patienttReport('$PateintName','$Pateints','$ptphone','$from','$to')";
    $result=mysqli_query($conn,$query);
    if ($result){
          while ($row=mysqli_fetch_assoc($result)){
          array_push($container, $row);
 
            }
            $data =array("status" =>true,"data" =>$container);
 
 
          }else{
             $data=["status"=>false,"data"=>$conn->error];
          }
          echo json_encode($data);
 
}
if(isset($_POST['action'])){
    $action=$_POST['action'];
    $action($conn);

}else{
    echo json_encode(array("status"=>false,"data"=>"Action Required"));
}



?>