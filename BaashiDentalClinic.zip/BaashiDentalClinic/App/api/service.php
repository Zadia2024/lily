<?php


function CreateService($conn){
    extract($_POST);
    $data=array();
    $query="INSERT INTO `service`(`name`, `price`) VALUES('$name','$price')";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Equipment Registered Successfully👍"); 
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);
}

function ReadData($conn){
    $data=array();
    $container=array();
    $query="SELECT * FROM service";
    $result=mysqli_query($conn,$query);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
         $data=array("status"=>true,"data"=>$row);
         array_push($container,$row);
        }
        $data=array("status"=>true,"data"=>$container);
    }else{
    $data=array("status"=>false,"data"=>$conn->error);
    }

    echo json_encode($data);
}


function FeachData($conn){
    $data=array();
    extract($_POST);
    $query="SELECT * FROM service WHERE id ='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
         $row=mysqli_fetch_assoc($result);
         $data=array("status"=>true,"data"=>$row);

    }else{
    $data=array("status"=>false,"data"=>$conn->error);
    }

    echo json_encode($data);
}



function updateData($conn){
    extract($_POST);
    $data=array();
    $query="UPDATE service SET  name='$name', price='$price' WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>" ✍️ Data updated successfully ✔️");
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);
}


function deleteData($conn){
    extract($_POST);
    $data=array();
    $query="DELETE FROM service WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data Deleted successfully");
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);
}








include "../config/conn.php";

if(isset($_POST['action'])){
    $action=$_POST['action'];
    $action($conn);
}else{
    echo json_encode(array("status"=>false,"data"=>"action not found"));
}




?>