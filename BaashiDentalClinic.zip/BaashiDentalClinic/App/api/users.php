<?php
include "../config/conn.php";

function UsersRegister($conn){
    extract($_POST);
    $data=array();
    $query="CALL users('$username','$password','$type','$status')";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result);
        if($row['msg']=="exsist"){
            $data=array("status"=>false,"data"=>"🫥Users Registered Successfully👌");
        }else{
            $data=array("status"=>true,"data"=>"😜Patient Allready Registered🫣");
        }
    }else{
    // echo $conn->error;
    $data=array("status"=>false,"data"=>$conn->error);
}
      echo json_encode($data);
}

/////// data soo aqrin function keeda
   function ReadData($conn){
    $data=[];
    $container=array();
    $query="SELECT * FROM `users` WHERE 1";
    $result=mysqli_query($conn,$query);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
        array_push($container,$row);    
        }
        $data=array("status"=>true,"data"=>$container);
    }else{  
    $data=["status"=>false,"data"=>$conn->error];
   }
   echo json_encode($data);
}
/////////////// Aqrinta intan ku ek ///////////////////

/////////////// Update  ///////////////////

function Feachdata($conn){
    extract($_POST);
    $data=array();
    $query="SELECT * FROM users WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result);
        $data=array("status"=>true,"data"=>$row);
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);

}

//////////udata/////////////

function updatedata($conn){
    $data=array();
    extract($_POST);
    $query="UPDATE users SET username='$username',password='$password',type='$type',Ai='$status' WHERE id='$update_id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data updated successfully");
    }else{
        $data=array("status"=>true,"data"=>$conn->error);
}
    echo json_encode($data);
}

///////Delete waaye/////////

function deletedata($conn){
    $data=array();
    extract($_POST);
    $query="DELETE FROM users WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data Deleted successfully");
    }else{
        $data=array("status"=>true,"data"=>$conn->error);
}
    echo json_encode($data);
}




if(isset($_POST['action'])){
    
    $action=$_POST['action'];
    $action($conn);
}else{
   echo json_encode($data=array("data"=>"action required")); 
}