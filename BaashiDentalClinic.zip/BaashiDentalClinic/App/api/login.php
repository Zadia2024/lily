<?php
include "../config/conn.php";

function login($conn){
    extract($_POST);
    $data=array();
    $query="CALL auth('$username','$password')";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result);
        if(isset($row['msg'])){
            if($row['msg']=="exsist"){
                $data=array("status"=>false,"data"=>"Username Or Password Are Incorrect");
            }else if($row['msg']=="lock"){
                $data=array("status"=>false,"data"=>"This User Is Locked contact Admin");
            }
        }else{
            session_start();
            foreach($row as $key => $value){
            $_SESSION[$key]=$value;
        }
        $data=array("status"=>true,"data"=>"login successfully");

    }
 
    }else{
    $data=array("status"=>false,"data"=>$conn->error);
}
      echo json_encode($data);
}




if(isset($_POST['action'])){
    
    $action=$_POST['action'];
    $action($conn);
}else{
   echo json_encode($data=array("data"=>"action required")); 
}