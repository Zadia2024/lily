<?php
include "../config/conn.php";

function patientRegister($conn){
    extract($_POST);
    $data=array();
    $query="CALL patientps('$name','$phone','$address','$sex')";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result);
        if($row['msg']=="exist"){
            $data=array("status"=>false,"data"=>"😜Patient Allready Registered🫣");
        }else{
            $data=array("status"=>true,"data"=>"🫥Patient Registered Successfully👌");
        }
    }else{
    // echo $conn->error;
    $data=array("status"=>false,"data"=>$conn->error);
}
      echo json_encode($data);
}

/////// data soo aqrin function keeda
   function ReadData($conn){
    $data=[];
    $container=array();
    $query="SELECT * FROM `patient` WHERE 1";
    $result=mysqli_query($conn,$query);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
        array_push($container,$row);    
        }
        $data=array("status"=>true,"data"=>$container);
    }else{  
    $data=["status"=>false,"data"=>$conn->error];
   }
   echo json_encode($data);
}

function pateintwithblance($conn){
    $data=[];
    $container=array();
    $query="SELECT r.pt_id,p.name FROM recieption r LEFT JOIN patient p ON r.pt_id=p.id WHERE r.price>0 GROUP BY p.id";
    $result=mysqli_query($conn,$query);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
        array_push($container,$row);    
        }
        $data=array("status"=>true,"data"=>$container);
    }else{  
    $data=["status"=>false,"data"=>$conn->error];
   }
   echo json_encode($data);
}
/////////////// Aqrinta intan ku ek ///////////////////

/////////////// Update  ///////////////////

function Feachdata($conn){
    extract($_POST);
    $data=array();
    $query="SELECT * FROM patient WHERE patient.id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result);
        $data=array("status"=>true,"data"=>$row);
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);

}

//////////udata/////////////

function updatedata($conn){
    $data=array();
    extract($_POST);
    $query="UPDATE patient SET name='$name',phone='$phone',address='$address',sex='$sex' WHERE id='$update_id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data updated successfully");
    }else{
        $data=array("status"=>true,"data"=>$conn->error);
}
    echo json_encode($data);
}

///////Delete waaye/////////

function deletedata($conn){
    $data=array();
    extract($_POST);
    $query="DELETE FROM patient WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data Deleted successfully");
    }else{
        $data=array("status"=>true,"data"=>$conn->error);
}
    echo json_encode($data);
}




if(isset($_POST['action'])){
    
    $action=$_POST['action'];
    $action($conn);
}else{
   echo json_encode($data=array("data"=>"action required")); 
}