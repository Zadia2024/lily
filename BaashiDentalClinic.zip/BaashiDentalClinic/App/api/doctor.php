<?php


function createdoctor($conn){
    extract($_POST);
    $data=array();
    $query="CALL doctors_sp('$name','$phone','$national','$Qualification','$salary')";
    $result=mysqli_query($conn,$query);
    if($result){
        $row=mysqli_fetch_assoc($result);
        if($row['msg']=="exist"){
            $data=array("status"=>false,"data"=>"🤦Doctor Allready Registered🫣");
        }else{
            $data=array("status"=>true,"data"=>"👨‍⚕️Doctor Registered Successfully👍");
        }
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);
}

function ReadData($conn){
    $data=array();
    $container=array();
    $query="SELECT * FROM doctors";
    $result=mysqli_query($conn,$query);
    if($result){
        while($row=mysqli_fetch_assoc($result)){
         $data=array("status"=>true,"data"=>$row);
         array_push($container,$row);
        }
        $data=array("status"=>true,"data"=>$container);
    }else{
    $data=array("status"=>false,"data"=>$conn->error);
    }

    echo json_encode($data);
}


function FeachData($conn){
    $data=array();
    extract($_POST);
    $query="SELECT * FROM doctors WHERE id ='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
         $row=mysqli_fetch_assoc($result);
         $data=array("status"=>true,"data"=>$row);

    }else{
    $data=array("status"=>false,"data"=>$conn->error);
    }

    echo json_encode($data);
}



function updateData($conn){
    extract($_POST);
    $data=array();
    $query="UPDATE doctors SET name='$name', phone='$phone', national='$national', Qualification='$Qualification', salary='$salary' WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>" ✍️ Data updated successfully ✔️");
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);
}


function deleteData($conn){
    extract($_POST);
    $data=array();
    $query="DELETE FROM doctors WHERE id='$id'";
    $result=mysqli_query($conn,$query);
    if($result){
        $data=array("status"=>true,"data"=>"Data Deleted successfully");
    }else{
        $data=array("status"=>false,"data"=>$conn->error);
    }
    echo json_encode($data);
}








include "../config/conn.php";

if(isset($_POST['action'])){
    $action=$_POST['action'];
    $action($conn);
}else{
    echo json_encode(array("status"=>false,"data"=>"action not found"));
}




?>