<?php


include "../config/conn.php";

function account($conn){
    extract($_POST);
    $data=array();
    $quary="CALL account_ps('$number','$blance','user_id')";
    $result=mysqli_query($conn,$quary);

    if($result){
     //echo"Successfully registered";
    $row=mysqli_fetch_assoc($result);
    ///print_r($row);
    if($row['msg']=="exist"){
        $data=array("status"=>false,"data"=>"😜Allready Registered🫣");
    }else{
        $data=array("status"=>true,"data"=>"🫥Successfully Registered👌");
    }
    
    }else{
       // echo $conn->error;
       $data=array("status"=>false,"data"=>$conn->error);
    }

    echo json_encode($data);
}



/////// data soo aqrin function keeda

function ReadData($conn){
    $data=[];
    $container=[];
    $query="SELECT * FROM `account` WHERE 1";
    $result=mysqli_query($conn,$query);
    if($result){
       
       while( $row=mysqli_fetch_assoc($result)){
       array_push($container,$row);
       }
       $data=array("status"=>true,"data"=>$container);
    }else{

        $data=["status"=>false,"data"=>$conn->error];
    }

    echo json_encode($data);
}




function FeachData($conn){
extract($_POST);
$data=array();
$query="SELECT * FROM account WHERE account.id='$id'";
$result=mysqli_query($conn,$query);

if($result){
    $row=mysqli_fetch_assoc($result);
    $data=array("status"=>true,"data"=>$row);
}else{
    $data=array("status"=>false,"data"=>$conn->error);
}

echo json_encode($data);
}



function updateData($conn){
 $data=array();
 extract($_POST);
 $query="UPDATE account SET number='$number',blance='$blance'where id='$update_id'";
 $result=mysqli_query($conn,$query);

 if($result){
    $data=array("status"=>true,"data"=>"😍Successfully Updated😊");
 }else{
    $data=array("status"=>true,"data"=>$conn->error);
 }
echo json_encode($data);
}

function DeleteData($conn){
    $data=array();
    extract($_POST);
    $query="DELETE FROM account where id='$id'";
    $result=mysqli_query($conn,$query);
   
    if($result){
       $data=array("status"=>true,"data"=>"😭Successfully Deleted😭");
    }else{
       $data=array("status"=>true,"data"=>$conn->error);
    }
   echo json_encode($data);
}


if (isset($_POST['action'])){
    $action=$_POST['action'];
    $action($conn);
}else{
    echo json_encode($data=array("data"=>"Action Required"));
}

    
?>